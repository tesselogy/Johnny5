
import time
from models import RawTrackState, ParticipantState, SceneState
from config import RECOGNITION_THRESHOLD, LOW_THRESHOLD, GRACE_PERIOD_SEC


class SceneEngine:

    def __init__(self):
        self.raw_tracks = {}
        self.scene = SceneState(timestamp=time.time())

    def update_from_perception(self, track_id, identity_match):

        now = time.time()

        self.raw_tracks[track_id] = RawTrackState(
            track_id=track_id,
            person_id=identity_match.person_id,
            similarity=identity_match.similarity,
            last_seen=now
        )

    def apply(self):

        now = time.time()
        active_person_keys = set()

        for track_id, raw in list(self.raw_tracks.items()):

            if raw.similarity >= RECOGNITION_THRESHOLD:
                identity_status = "RECOGNIZED"
            elif raw.similarity >= LOW_THRESHOLD:
                identity_status = "PROBABILISTIC"
            else:
                identity_status = "UNRECOGNIZED"

            if raw.person_id:
                person_key = raw.person_id
            else:
                person_key = f"unknown:{track_id}"

            active_person_keys.add(person_key)

            if person_key not in self.scene.participants:
                self.scene.participants[person_key] = ParticipantState(
                    person_key=person_key,
                    person_id=raw.person_id,
                    current_track_id=track_id,
                    identity_status=identity_status,
                    last_seen=now
                )
            else:
                participant = self.scene.participants[person_key]
                participant.current_track_id = track_id
                participant.last_seen = now

        for person_key, participant in list(self.scene.participants.items()):
            if person_key not in active_person_keys:
                if participant.last_seen + GRACE_PERIOD_SEC < now:
                    del self.scene.participants[person_key]

        self.scene.timestamp = now
