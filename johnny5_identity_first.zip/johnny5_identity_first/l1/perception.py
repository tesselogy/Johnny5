
import cv2
from l1.detector import PersonDetector
from l1.face_encoder import FaceEncoder
from l1.faiss_index import IdentityIndex
from models import IdentityMatch


class Perception:

    def __init__(self):
        self.detector = PersonDetector()
        self.encoder = FaceEncoder()
        self.index = IdentityIndex()

    def draw_overlay(self, frame, track_id, bbox, similarity):
        x1, y1, x2, y2 = bbox
        color = (0, 255, 0) if similarity >= 0.75 else (0, 165, 255)

        cv2.rectangle(frame, (x1, y1), (x2, y2), color, 2)

        label = f"{track_id} | {similarity:.2f}"

        cv2.putText(
            frame,
            label,
            (x1, y1 - 10),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.5,
            color,
            2
        )

    def process_frame(self):

        frame, tracks = self.detector.get_next()
        identity_results = []

        for track_id, x1, y1, x2, y2, conf in tracks:

            embedding, quality = self.encoder.extract(
                frame, (x1, y1, x2, y2)
            )

            if embedding is None:
                identity_results.append((track_id, IdentityMatch(None, 0.0)))
                continue

            matches = self.index.search(embedding)

            if matches:
                person_id, similarity = matches[0]
            else:
                person_id, similarity = None, 0.0

            identity_results.append(
                (track_id, IdentityMatch(person_id, similarity))
            )

            self.draw_overlay(
                frame,
                track_id,
                (x1, y1, x2, y2),
                similarity
            )

        cv2.imshow("Johnny5 Identity-First Vision", frame)
        cv2.waitKey(1)

        return identity_results
